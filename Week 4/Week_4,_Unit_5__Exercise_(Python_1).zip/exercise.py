with ("invoice_data.txt", "r") as file:
    